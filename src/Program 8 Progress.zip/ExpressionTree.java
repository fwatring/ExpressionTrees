import java.util.Stack;

public class ExpressionTree {
  BinTreeNode root;

  public ExpressionTree(String postfixExpression) {
    Stack<BinTreeNode> stack = new Stack<BinTreeNode>();
    String[] postfixArray;
    postfixArray = postfixExpression.split(" ");
    for (int i = 0; i < postfixArray.length; i++) {

      if (postfixArray[i].equals("*") || postfixArray[i].equals("/") || postfixArray[i].equals("+")
          || postfixArray[i].equals("-")) {
        BinTreeNode node = new BinTreeNode(true, postfixArray[i].charAt(0), null, null);
        node.right = stack.peek();
        stack.pop();
        node.left = stack.peek();
        stack.pop();
        stack.push(node);
      } else {
        BinTreeNode node = new BinTreeNode(false, Integer.parseInt(postfixArray[i]), null, null);
        stack.push(node);
      }
      root = stack.peek();

    }
  }

  public String getPrefixNotation() {

    return getPrefixNotation(root);
  }

  public String getInfixNotation() {
    return "";
  }

  public int getValue() {
    return 0;
  }

  private String getPrefixNotation(BinTreeNode node) {
    String prefix = "";
    if (node != null) {

      if (node.isOperator) {
        prefix += node.symbol;
        prefix += " ";

        // what is this going to return always? which node are you looking at here
      } else {
        prefix += node.value;
        prefix += " ";
      }
      prefix += getPrefixNotation(node.left);
      prefix += getPrefixNotation(node.right);
    }
    return prefix;
  }

  private String getInfixNotation(BinTreeNode root) {
    return "";
  }

  private int getValue(BinTreeNode root) {
    return 0;
  }
}
